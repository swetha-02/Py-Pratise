import logging

logging.basicConfig(level=logging.WARNING,filemode='w',filename='demo.log',format="%(asctime)s-%(levelname)s-%(message)s")

# logger=logging.getLogger()

c=int(input("Enter number 1:"))
d=int(input("Enter number 2:"))

if c<0 and d<0:
    print(c+d)
else:
    logging.debug("Debug msg")
    logging.info("INFO msg")
    logging.warning("This is a warning message")
    logging.critical("Critical message")
    logging.error("Error message")