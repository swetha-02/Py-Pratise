import pdb

# x=5
# c=x+5
# pdb.set_trace()
# print(c)

def double(x):
   pdb.set_trace()
   return x * 2
val = 3
print(f"{val} * 2 is {double(val)}")