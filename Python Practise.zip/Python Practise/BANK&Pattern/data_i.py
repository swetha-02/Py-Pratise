import json

with open("C:/Users/swetha.s/Desktop/Python Practise/BANK&Pattern/datas.json", "r") as file:
    data = json.load(file)
