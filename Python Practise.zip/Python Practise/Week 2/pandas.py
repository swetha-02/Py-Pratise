#!/usr/bin/env python
# coding: utf-8

# In[153]:


import pandas as pd


# In[154]:


#Different ways of craeting Dataframe
# usingcsv
# usingexcel
# from dict
# read_sql
# read_json
# from list of tuples
# from list of dictionaries, etc......


# In[167]:


#create Dataframe

#Read csv--------------
df = pd.read_csv('C:/Users/BUSOFT/Downloads/sample.csv')
# df

#Read Excel--------------
# df2 = pd.read_excel("path.xlsx","sheet1")
# df2


dict1 = df.to_dict()
# list1 = df.to_json()
# print(dict1)
# to print values
# print(df.values)
#Read Dictionary-------------------
dictdf = pd.DataFrame(dict1)
# dictdf
#to find the datatype
df.dtypes

#Read List of tuples---------------------------
wd = [
    ('1/1/17',32,6,'Rain')
]
df3 = pd.DataFrame(wd,columns = ['day','temp','speed','event'])
print(df3)

#Read List of dictionaries---------------------------
ld = [
    {'day':'1/1/17','temp':32,'speed':6,'event':'Rain'},
    {'day':'1/1/17','temp':32,'speed':6,'event':'Rain'}
]
df4 = pd.DataFrame(ld)
print(df4)

#Read List of list---------------------------
ll= [
    ['1/1/17',32,6,'Rain']
]
df5 = pd.DataFrame(ll,columns = ['day','temp','speed','event'])
print( df5)


# In[164]:


#print the no of rows and columns
df.shape


# In[165]:


#head() - print Top 5 rows
#tail() - print Last 5 rows
print(df.head(1))
print(df.tail(1))


# In[115]:


#DataFrame indexing and slicing
# df[1:5]
print(df.loc[[1,2]])
# df[1,2]
# df.loc[1]


# In[166]:


#print columns
df.columns


# In[171]:


#to print particular column 
# df.windspeed
# or
df['Wind speed']


# In[173]:


print(df.dtypes)
type(df['day'])


# In[174]:


# operations in df

#find max temperature
max_temp = df['temperature'].max()
print(max_temp)

min_temp = df['temperature'].min()
print(min_temp)


# In[50]:


# statistics of table
df.describe()


# In[185]:


df[['day','temperature','event']][df['event']=='rain']


# In[113]:


#conditional statements
#rain 

rain = df[df['event'] == 'rain']
rain

#temp greater than 32

tempabove33 = df[df.temperature >= 33]
tempabove33

#for select particular column

c= df['event'] == 'snow'

selectedcolumn = df[['day','temperature','event']][(df['event'] == 'rain') | c]
selectedcolumn

df.count()


# In[114]:


df.index


# In[116]:


# df.set_index('day',inplace = True)
# df.loc['01/01/17']
#to reset the index
# df.reset_index


# In[132]:


# to skip rows
# df11 = pd.read_csv('C:/Users/BUSOFT/Downloads/sample.csv',skiprows=1)
# df11 = pd.read_csv('C:/Users/BUSOFT/Downloads/sample.csv',header = None,names = ["day","temp","speed","td"])
# df11 = pd.read_csv('C:/Users/BUSOFT/Downloads/sample.csv',nrows=2) 

# df11


# In[188]:


import numpy as np
# clean up messy data
# df12 = pd.read_csv('C:/Users/BUSOFT/Downloads/sample.csv',na_values=[-99999,'n.a','NaN'])
# df13 = pd.read_csv('C:/Users/BUSOFT/Downloads/sample.csv',na_values={
#     'event':['n.a','NaN']
# }
# df12.dropna()
# df.fillna(130,inplace=True)
# df.fillna(method ='ffill',limit = 1) #forwardfill
#df.fillna(method ='bfill') #backwardfill
new = df12.interpolate()
new
# tresh = df12.dropna(thresh =1)
# tresh
# df16 = pd.read_csv('C:/Users/BUSOFT/Downloads/sample.csv')
# new_df = df16.replace(-99999,np.NaN)
# new_df
df12


# In[136]:


# df.to_csv("path.csv",columns = ['col1','col2'])


# In[137]:


#df = pd.read_csv("path.csv",parse_dates = ["day"])


# In[ ]:




