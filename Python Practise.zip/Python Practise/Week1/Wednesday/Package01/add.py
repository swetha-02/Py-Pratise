def add(a,b):
    a=2
    b=3
    c=a+b
    print(c)