def sub(a,b):
    a=4
    b=2
    c=a-b
    print(c)