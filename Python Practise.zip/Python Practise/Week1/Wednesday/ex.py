import Package01

result=Package01.add(2,3)
print(result)
result1=Package01.sub(2,3)
print(result1)