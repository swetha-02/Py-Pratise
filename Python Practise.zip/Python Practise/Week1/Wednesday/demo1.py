def func():
    for i in range(1,20):
        print(i)
        