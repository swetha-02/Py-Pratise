from fastapi import FastAPI,HTTPException
import uvicorn
import mysql.connector
from contextlib import asynccontextmanager
from pydantic import BaseModel

class user_data(BaseModel):
    user_name : str
    mob_no : int   

class user_data_put(BaseModel):
    user_id:int
    user_name:str
    mob_no:int

class users_data_patch(BaseModel):
    user_id:int
    col_name:str
    col_value: str

class users_data_delete(BaseModel):
    user_id: int


def connect():return mysql.connector.connect(
        host='3.7.198.191',
        user='bu-trausr',
        password='r9*rwr$!usFw0MCPj#fJ',
        database='bu-training',
        port=8993,
        auth_plugin='mysql_native_password')

def initialize_db():
    con=connect()
    cur=con.cursor()
    query="""create table IF NOT EXISTS fastapi_user
    (user_id int AUTO INCREMENT PRIMARY KEY,user_name varchar(50),mob_no bigint)"""
    cur.execute(query)
    con.close()

def get_users():
    con=connect()
    cur=con.cursor()
    query="select*from fastapi_user"
    cur.execute(query)
    con.close()
    val=cur.fetchall()
    users=[]
    for i in val:
        users.append({"user_id":i[0],"username":i[1],"mob_no":i[2]})
    print(users)
    return users

def get_user_id(user_id):
    con=connect()
    cur=con.cursor()
    query="select*from fastapi_user where user_id="+str(user_id)
    cur.execute(query)
    con.close()
    val=cur.fetchall()
    print(val)
    user={"id":val[0][0],"user_name":val[0][1],"mob_no":val[0][2]}
    print(user)
    return user

def insert_user_mobile(user_name:str,mob_no:int):
    con=connect()
    cur=con.cursor()
    query="insert into fastapi_user(user_name,mob_no)values('"+user_name+"','"+str(mob_no)+"')"
    cur.execute(query)
    con.commit()
    con.close()
    return cur.lastrowid

def update_mobile(user_id:int,user_name:str,mob_no:int):
    con=connect()
    cur=con.cursor()
    query="update fastapi_user set user_name='"+user_name+"',mob_no='"+str(mob_no)+"' where user_id='"+str(user_id)+"'"
    cur.execute(query)
    con.commit()
    con.close()
    return 1

def update_val_user_mobile(user_id : int,col_name:str,col_val:str):
    con = connect()
    cur = con.cursor()
    query = "update fastapi_user set "+col_name+" = '"+col_val+"' where user_id ='"+str(user_id)+"'"
    cur.execute(query)
    con.commit()
    con.close()
    return 1

def delete_user_mobile(user_id : int):
    con = connect()
    cur = con.cursor()
    q="Select * from fastapi_user where user_id = "+str(user_id)
    cur.execute(q)
    value = cur.fetchall()
    print(value)
    query = "delete from  fastapi_user where user_id ='"+str(user_id)+"'"
    cur.execute(query)
    con.commit()
    con.close()
    return value

@asynccontextmanager
async def lifespan(app:FastAPI):
    initialize_db()

app=FastAPI()

@app.get("/users")
async def users():
    users=get_users()
    return {"users":users}

@app.get('/users/{id}')
async def get_user(user_id:int):
    user=get_user_id(user_id)
    return user

@app.post("/")
async def add_user(user:user_data):
    user_i=insert_user_mobile(user.user_name,user.mob_no)
    if user_i:
        return {"Name":user.user_name,"Mobile number":user.mob_no}
    else:
        raise HTTPException(status_code=400,detail="User not created")
    
@app.put("/update")
async def add_user(user:user_data_put):
    user_i=update_mobile(user.user_id,user.user_name,user.mob_no)
    if user_i:
        return {"Name":user.user_name,"Mobile number":user.mob_no}
    else:
        raise HTTPException(status_code=400,detail="User not created")

@app.patch("/update_val")
async def add_user(user:users_data_patch):
    user_i=update_val_user_mobile(user.user_id,user.col_name,user.col_value)
    if user_i:
        return {"user_id":user.user_id,"updated column":user.col_name,"column value":user.col_value}
    else:
        raise HTTPException(status_code=400,detail="User not created")

@app.delete("/delete")
async def add_user(user:users_data_delete):
    user_i=delete_user_mobile(user.user_id)
    if user_i:
        return {"Deleted user":user_i}
    else:
        raise HTTPException(status_code=400,detail="User not created")


