from datetime import datetime, timedelta, timezone
from typing import Annotated
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError,jwt
import secrets
from passlib.context import CryptContext
from pydantic import BaseModel

SECRET_KEY= secrets.token_urlsafe(32)
ALGORITHM="HS256"
ACCESS_TOKEN_EXPIRE_MINUTES=60
