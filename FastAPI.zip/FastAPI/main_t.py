from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from passlib.context import CryptContext
from jose import JWTError, jwt
from datetime import datetime, timedelta
import mysql.connector
import secrets
from pydantic import BaseModel
from typing import List

app = FastAPI()

SECRET_KEY = secrets.token_urlsafe(32)
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 10

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: timedelta):
    to_encode = data.copy()
    expire = datetime.utcnow() + expires_delta
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

db_config = {
    "host": '3.7.198.191',
    "user": 'bu-trausr',
    "password": 'r9*rwr$!usFw0MCPj#fJ',
    "database": 'bu-training',
    "port": 8993,
    "auth_plugin": 'mysql_native_password'
}

def get_db_connection():
    connection = mysql.connector.connect(**db_config)
    try:
        yield connection
    finally:
        connection.close()

def authenticate_user(username: str, password: str, connection: mysql.connector.connection.MySQLConnection):
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT user_name, password_hash FROM fastapi_user_email WHERE user_name = %s", (username,))
        user = cursor.fetchone()
        if not user or not verify_password(password, user["password_hash"]):
            return False
        return user
    except mysql.connector.Error as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error",
        )
    finally:
        cursor.close()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

@app.post("/token")
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), conn: mysql.connector.connection.MySQLConnection = Depends(get_db_connection)):
    user = authenticate_user(form_data.username, form_data.password, conn)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["user_name"]}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/protected/")
async def protected_route(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    return {"message": "You're accessing a protected route!"}

class UserCreate(BaseModel):
    user_name: str
    password: str
    email: str

@app.post("/users/", response_model=UserCreate)
async def create_user(user: UserCreate, conn: mysql.connector.connection.MySQLConnection = Depends(get_db_connection)):
    cursor = conn.cursor()
    try:
        hashed_password = pwd_context.hash(user.password)
        cursor.execute(
            "INSERT INTO fastapi_user_email (user_name, password_hash, email) VALUES (%s, %s, %s)",
            (user.user_name, hashed_password, user.email)
        )
        conn.commit()
        return user
    except mysql.connector.Error as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error",
        )
    finally:
        cursor.close()

class User(BaseModel):
    user_name: str
    email: str

@app.get("/users/", response_model=List[User])
async def get_all_users(conn: mysql.connector.connection.MySQLConnection = Depends(get_db_connection)):
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT user_name, email FROM fastapi_user_email")
        users = cursor.fetchall()
        user_objects = [User(**user) for user in users]
        
    except mysql.connector.Error as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error",
        )
    finally:
        cursor.close()
    return user_objects


def delete_user(user_id: int, connection: mysql.connector.connection.MySQLConnection):
    cursor = connection.cursor()
    try:
        cursor.execute("DELETE FROM fastapi_user_email WHERE user_id = %s", (str(user_id),))
        connection.commit()
    except mysql.connector.Error as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error",
        )
    finally:
        cursor.close()
    return {"Message":"User Deleted"}

@app.delete("/users/{id}")
async def delete_user_endpoint(user_id: int, conn: mysql.connector.connection.MySQLConnection = Depends(get_db_connection)):
    delete=delete_user(user_id, conn)
    return delete