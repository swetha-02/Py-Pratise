import uvicorn
from fastapi import FastAPI,HTTPException
import mysql.connector
from contextlib import asynccontextmanager
from pydantic import BaseModel

class users_data(BaseModel):
    name : str
    password : str

def connect():
    return mysql.connector.connect(
        host="13.234.23.222",
	    user="priyadharshini.m",
	    password=" ",
	    database="reports_training",
	    port=8772,
	    auth_plugin='mysql_native_password'
    )

def initialize_db():
    conn = connect()
    cursor = conn.cursor()
    query = """
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255),
        password VARCHAR(255)
    )
    """
    cursor.execute(query)
    conn.close()

def create_user(user_name:str,password : str):
    conn = connect()
    cursor = conn.cursor()
    query = "INSERT INTO users (user_name, password) VALUES (%s, %s)"
    values = (user_name, password)
    cursor.execute(query, values)
    conn.commit()
    conn.close()
    return cursor.lastrowid

def get_users():
    conn = connect()
    cursor = conn.cursor()
    query = "Select userId,user_name,password from users"
    cursor.execute(query)
    conn.close()
    values = cursor.fetchall()
    users=[]
    for i in values:
        users.append({"id" : i[0],"username" : i[1]})

    print(users)
    return users

def get_user_detail(user_id):
    conn = connect()
    cursor = conn.cursor()
    query = "Select userId,user_name,password from users where userId = "+str(user_id)
    cursor.execute(query)
    conn.close()
    values = cursor.fetchall()
    print(values)
    user = {"id" : values[0][0],"user_name":values[0][1]}
    
    return user

@asynccontextmanager
async def lifespan(app:FastAPI):
    initialize_db()


app = FastAPI()

@app.get('/users')
async def users():
    users = get_users()
    return {"users":users }

@app.get('/users/{id}')
async def get_user(user_id:int):
    user = get_user_detail(user_id)
    return user

@app.post("/users")
async def add_user(user : users_data):
    # print(user.name)
    # print(user.password)
    user_id = create_user(user.name,user.password)
    if user_id:
        return {'id':user_id,"username":user.name}
    else:
        raise HTTPException(status_code=400, detail="User not created")
    
