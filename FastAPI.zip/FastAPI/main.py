import uvicorn
from fastapi import FastAPI,HTTPException
import mysql.connector
from contextlib import asynccontextmanager
from pydantic import BaseModel


class users_data(BaseModel):
    user_name : str
    mobile_number : int
    age:int

class users_data_put(BaseModel):
    user_id : int
    user_name : str
    mobile_number : int
    age:int

class users_data_patch(BaseModel):
    user_id : int
    col_name : str
    col_value : str
    
class users_data_delete(BaseModel):
    user_id : int

def connect():
    return mysql.connector.connect(
        host='3.7.198.191',
        user='bu-trausr',
        password='r9*rwr$!usFw0MCPj#fJ',
        database='bu-training',
        port=8993,
        auth_plugin='mysql_native_password'
    )

def initialize_db():
    conn = connect()
    cursor = conn.cursor()
    query = """
    create table IF NOT EXISTS fastapi_user_mobile
    (user_id int AUTO_INCREMENT PRIMARY KEY,user_name varchar(50),mobile_number bigint)
    """
    cursor.execute(query)
    conn.close()

def delete_user_mobile(user_id : int):
    conn = connect()
    cursor = conn.cursor()
    q="Select * from fastapi_user_mobile where user_id = "+str(user_id)
    cursor.execute(q)
    value = cursor.fetchall()
    print(value)
    query = "delete from  fastapi_user_mobile where user_id ='"+str(user_id)+"'"
    cursor.execute(query)
    conn.commit()
    conn.close()
    return value

def update_val_user_mobile(user_id : int,col_name:str,col_val:str):
    conn = connect()
    cursor = conn.cursor()
    query = "update fastapi_user_mobile set "+col_name+" = '"+col_val+"' where user_id ='"+str(user_id)+"'"
    cursor.execute(query)
    conn.commit()
    conn.close()
    return 1

def update_user_mobile(user_id : int,user_name:str,mobile_number:int,age : int):
    conn = connect()
    cursor = conn.cursor()
    query = "update fastapi_user_mobile set user_name = '"+user_name+"', mobile_number = '"+str(mobile_number)+"',age = '"+str(age)+"' where user_id ='"+str(user_id)+"'"
    cursor.execute(query)
    conn.commit()
    conn.close()
    return 1

def insert_user_mobile(user_name:str,mobile_number:int,age : int):
    conn = connect()
    cursor = conn.cursor
    query = "INSERT INTO fastapi_user_mobile (user_name, mobile_number,age) VALUES ('"+user_name+"','"+str(mobile_number)+"','"+str(age)+"')"
    cursor.execute(query)
    conn.commit()
    conn.close()
    return cursor.lastrowid

def get_users():
    conn = connect()
    cursor = conn.cursor()
    query = "Select * from fastapi_user_mobile"
    cursor.execute(query)
    conn.close()
    values = cursor.fetchall()
    users=[]
    for i in values:
        users.append({"user_id" : i[0],"username" : i[1],"mobile number":i[2],"Age":i[3]})

    print(users)
    return users

def get_user_detail(user_id):
    conn = connect()
    cursor = conn.cursor()
    query = "Select * from fastapi_user_mobile where user_id = "+str(user_id)
    cursor.execute(query)
    conn.close()
    values = cursor.fetchall()
    print(values)
    user = {"id" : values[0][0],"user_name":values[0][1],"mobile number":values[0][2],"age":values[0][3]}
    print(user)
    return user

@asynccontextmanager
async def lifespan(app:FastAPI):
    initialize_db()

app = FastAPI()

@app.get('/users')
async def users():
    users = get_users()
    return {"users":users }

@app.get('/users/{id}')
async def get_user(user_id:int):
    user = get_user_detail(user_id)
    return user

@app.post("/")
async def add_user(user : users_data):
    user_i = insert_user_mobile(user.user_name,user.mobile_number,user.age)
    if user_i:
        return {'Name':user.user_name,"Mobile number":user.mobile_number,"Age":user.age}
    else:
        raise HTTPException(status_code=400, detail="User not created")
    

@app.put("/update")
async def add_user(user : users_data_put):
    user_i = update_user_mobile(user.user_id,user.user_name,user.mobile_number,user.age)
    if user_i:
        return {'Name':user.user_name,"Mobile number":user.mobile_number,"Age":user.age}
    else:
        raise HTTPException(status_code=400, detail="User not created")
    
@app.patch("/update_val")
async def add_user(user : users_data_patch):
    user_i = update_val_user_mobile(user.user_id,user.col_name,user.col_value)
    if user_i:
        return {"user id":user.user_id,"updated column":user.col_name,"column value":user.col_value}
    else:
        raise HTTPException(status_code=400, detail="User not created")
    
@app.delete("/delete")
async def add_user(user : users_data_delete):
    user_i = delete_user_mobile(user.user_id)
    if user_i:
        return {"Deleted user":user_i}
    else:
        raise HTTPException(status_code=400, detail="User not created")