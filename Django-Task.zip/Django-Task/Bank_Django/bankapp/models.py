from django.db import models

class BankAccountPython(models.Model):
    acc_no = models.IntegerField(primary_key=True,db_column='Acc_no')  
    name = models.CharField(db_column='Name', max_length=50, blank=True, null=True)  
    email = models.CharField(db_column='Email', max_length=100, blank=True, null=True)  
    password = models.CharField(db_column='Password', max_length=20, blank=True, null=True)  
    mobile_number = models.BigIntegerField(db_column='Mobile_number', blank=True, null=True)  
    balance = models.FloatField(db_column='Balance', blank=True, null=True)  

    class Meta:
        managed = False
        db_table = 'Bank_Account_Python'
