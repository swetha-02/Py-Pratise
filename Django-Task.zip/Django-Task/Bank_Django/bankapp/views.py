from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.template import loader
from .models import BankAccountPython
from django.db import connection
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def login(request):
    temp=loader.get_template("login.html")
    return HttpResponse(temp.render())

@csrf_exempt
def log(request):
    val=BankAccountPython.objects.all()
    context={'val':val}
    return render(request,'home.html',context)

@csrf_exempt
def func(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        
        user=BankAccountPython.objects.filter(email=email,password=password).first()

        if user:
            request.session['email']=email
            return render(request,'home.html')
        else:
            error_message="Ivalid email or password."
            return render(request,"login.html",{'error':error_message})
    # return render(request,"login.html")
