from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from . import models

def func(request):
    temp=loader.get_template("index.html")
    return HttpResponse(temp.render())

def data_access(request):
    m=models.demo.objects.all().values()
    temp1=loader.get_template('data.html')
    context={'my':m}
    return HttpResponse(temp1.render(context,request))

def record_fetch(request,id):
    m1=models.demo.objects.get(id=id)
    temp2=loader.get_template("datafetch.html")
    context={'data':m1}
    return HttpResponse(temp2.render(context,request))

def posting(request):
    a=request.POST
    f=''
    l=''
    if(len(a)>0):
        for k,v in a.items():
            if k=="first_name":
                f=a[k]
            if k=="last_name":
                l=a[k]
    print("The value is:",f,l)
    var=models.demo(first_name=f,last_name=l)
    var.save()
    temp=loader.get_template('post.html')
    context={}
    return HttpResponse(temp.render(context,request))
    # return HttpResponse("Hello World")
# Create your views here.
