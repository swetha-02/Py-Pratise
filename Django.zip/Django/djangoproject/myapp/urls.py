from django.urls import path
from . import views
urlpatterns = [
    path('home/', views.func),
    path('data/',views.data_access),
    path('details/<int:id>/',views.record_fetch),
    path('data_put/',views.posting)
]