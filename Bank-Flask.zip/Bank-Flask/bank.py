from flask import Flask, render_template, request, redirect,url_for
import mysql.connector
sample=Flask(__name__)

@sample.route('/')
def login():
    return render_template("login.html",error='')

@sample.route('/home')
def home():
    return render_template("home.html")

v=""
@sample.route('/bal')
def check_balance():
    db=mysql.connector.connect(host="3.7.198.191",user="bu-trausr",password="r9*rwr$!usFw0MCPj#fJ",
                               database="bu-training",port=8993,auth_plugin="mysql_native_password")
    cur=db.cursor()
    query="select Balance from Bank_Account_Python where Name='"+v+"'"  
    cur.execute(query)
    result=cur.fetchall()
    print(result)
    return render_template("balance.html",bal=result[0][0])

@sample.route('/login',methods=['POST'])
def loginval():
    email=request.form['email']
    password=request.form['pwd']
    db=mysql.connector.connect(host="3.7.198.191",user="bu-trausr",password="r9*rwr$!usFw0MCPj#fJ",
                               database="bu-training",port=8993,auth_plugin="mysql_native_password")
    cur=db.cursor()
    query="select * from Bank_Account_Python where Email='"+email+"' and Password='"+password+"'" 
    cur.execute(query)
    result=cur.fetchall()
    global v
    
    if (len(result)!=0):
        v=result[0][1]
        return render_template("home.html",val=v)
    else:
        return render_template("login.html",error="Invalid Email or Password")
    
@sample.route('/password')
def password():
    return render_template("password_error.html")
    
@sample.route('/pass',methods=['POST'])
def changepass():
    new_password=request.form['pass_new']
    if new_password!="":
        db=mysql.connector.connect(host="3.7.198.191",user="bu-trausr",password="r9*rwr$!usFw0MCPj#fJ",
                                database="bu-training",port=8993,auth_plugin="mysql_native_password")
        cur=db.cursor()
        query="update Bank_Account_Python set Password='"+new_password+"' where Name='"+v+"'"
        cur.execute(query)
        db.commit()
        return render_template("password.html")
    else:
        return render_template("password_error.html",error="Cannot change Password. Try Again")

@sample.route('/withdraw')
def withdraw():
    return render_template("withdraw.html")

@sample.route('/amt_withdraw',methods=['POST'])
def amt_withdraw():
    amount=request.form['amount']
    db=mysql.connector.connect(host="3.7.198.191",user="bu-trausr",password="r9*rwr$!usFw0MCPj#fJ",
                            database="bu-training",port=8993,auth_plugin="mysql_native_password")
    cur=db.cursor()
    balance_amt="select Balance from Bank_Account_Python where Name='"+v+"'"
    cur.execute(balance_amt)
    res=cur.fetchall()
    x=res[0][0]
    if int(amount)<=0 and int(amount)>x:
        return render_template("withdraw.html",error="Invalid amount withdrawn")
    else:
        db=mysql.connector.connect(host="3.7.198.191",user="bu-trausr",password="r9*rwr$!usFw0MCPj#fJ",
                            database="bu-training",port=8993,auth_plugin="mysql_native_password")
        cur=db.cursor()
        query="update Bank_Account_Python set Balance=Balance-'"+amount+"'where Name='"+v+"'"
        cur.execute(query)
        db.commit()
        db.close()
        balance_query="select Balance from Bank_Account_Python where Name='"+v+"' "
        cur.execute(balance_query)
        res=cur.fetchall()
        return render_template("amt.html",y=res[0][0])
        
if __name__=="__main__":
    sample.run(debug=True)   